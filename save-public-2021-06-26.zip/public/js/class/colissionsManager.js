"use strict";
class CollisionsManager {
	constructor() {
		if (WLOG) console.log("Empty CollisionsManager Class Mounted!")
	}
}
