# sources 
you'r feeling bad cause i'm using your stuff ;( tell me and i'll remove it as soon !
sorry for the mess and thx for your great job ;)

https://www.freepik.com/premium-vector/pixel-art-game-background-grass-sky-clouds_9047947.htm

https://design.tutsplus.com/tutorials/how-to-create-a-pixel-game-ui-in-adobe-photoshop--cms-22005

https://image.freepik.com/vecteurs-libre/fond-jeu-montagne_22191-30.jpg

https://www.vecteezy.com/vector-art/265089-seamless-tropical-beach-landscape-for-ui-game

https://www.vecteezy.com/vector-art/455691-seamless-western-desert-landscape-for-ui-game


# Testing Background slider so far !

Level 1 - #NiceDayToRun ! / bossname: "HashTagMHell"

![map1](bg_lvl_1.jpg?raw=true "map1")

Level 2 - Falling Sheet Cascading / bossname: "SeeDouble Ace"

![map2](bg_lvl_2.gif?raw=true "map2")

Level 3 - Bottom:Root Path / bossname: "Silver Ass"

![map3](bg_lvl_3.jpg?raw=true "map3")

Level 4 - Java's Crypte / bossname: "JiAce"

![map4](bg_lvl_4.jpg?raw=true "map4")

Level 5 - Last Level / bossname: "ConsoleLog"

![map5](bg_lvl_5.jpg?raw=true "map5")
