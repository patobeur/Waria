https://oco.itch.io/

# Testing Animation so far !
Btw, thx to Clembod for his nices pixelarts
https://clembod.itch.io

waria_idle right
![waria_idle](warrior/waria_idle.gif?raw=true "waria_idle")

waria_idle left
![waria_idle_l](warrior/waria_idle_l.gif?raw=true "waria_idle_l")

waria_run
![waria_run](warrior/waria_run.gif?raw=true "waria_run")

waria_run left
![waria_run_l](warrior/waria_run_l.gif?raw=true "waria_run_l")

waria_jump
![waria_jump](warrior/waria_jump.gif?raw=true "waria_jump")

waria_jump left
![waria_jump_l](warrior/waria_jump_l.gif?raw=true "waria_jump_l")

waria_attack right
![waria_dask_attack](warrior/waria_dask_attack.gif?raw=true "waria_dask_attack")

waria_attack left
![waria_dask_attack_l](warrior/waria_dask_attack_l.gif?raw=true "waria_dask_attack_l")
